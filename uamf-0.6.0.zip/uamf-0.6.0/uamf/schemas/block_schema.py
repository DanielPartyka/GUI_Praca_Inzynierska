block_schema = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "Block Metadata",
    "type": "object",
    "properties": {
        "filename": {
            "type": "string"
        },
        "origin_name": {
            "type": "string"
        },
        "height": {
            "type": "integer"
        },
        "width": {
            "type": "integer"
        },
        "pos_x": {
            "type": "integer"
        },
        "pos_y": {
            "type": "integer"
        },
        "rows_number": {
            "type": "integer"
        },
        "columns_number": {
            "type": "integer"
        },
        "spots_number": {
            "type": "integer"
        },
        "spots": {
            "type": "array",
            "oneOf": [
                {
                    "maxItems": 0
                },
                {
                    "minItems": 1,
                    "items": {
                        "$ref": "#/definitions/spot_as_dict"
                    }
                },
                {
                    "minItems": 1,
                    "items": {
                        "$ref": "#/definitions/spot_as_list"
                    }
                }
            ]
        },
        "mean_spot_height": {
            "type": "number"
        },
        "mean_spot_width": {
            "type": "number"
        },
        "griding_method": {
            "type": "string"
        },
        "griding_manually_verified": {
            "type": "boolean"
        }
    },
    "required": [
        "filename",
        "origin_name",
        "height",
        "width",
        "pos_x",
        "pos_y",
        "rows_number",
        "columns_number",
        "spots_number",
        "spots",
        "mean_spot_height",
        "mean_spot_width",
        "griding_method",
        "griding_manually_verified"
    ],
    "definitions": {
        "spot_as_dict": {
            "type": "object",
            "properties": {
                "index": {
                    "type": "integer"
                },
                "row": {
                    "type": "integer"
                },
                "column": {
                    "type": "integer"
                },
                "pos_x": {
                    "type": "integer"
                },
                "pos_y": {
                    "type": "integer"
                },
                "height": {
                    "type": "integer"
                },
                "width": {
                    "type": "integer"
                },
                "center_x": {
                    "type": "integer"
                },
                "center_y": {
                    "type": "integer"
                },
                "manually_verified": {
                    "type": "boolean"
                }
            },
            "required": [
                "index",
                "row",
                "column",
                "pos_x",
                "pos_y",
                "height",
                "width",
                "center_x",
                "center_y",
                "manually_verified"
            ]
        },
        "spot_as_list": {
            "type": "array",
            "items": [
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "integer"
                },
                {
                    "type": "boolean"
                }
            ]
        }
    }
}
