from dataclasses import dataclass
from typing import Union


@dataclass
class Size:
    # noinspection PyUnresolvedReferences
    """Size data structure

    Args:
        height (Union[int, float]): object height
        width (Union[int, float]): object width

    Example:
        >>> size = Size(120, 152)
        >>>
        >>> object_height = size.height  # get object height
        >>> size.width = 12 # set object width to 12

    **The parameters of the Size object are also its attributes**
    """

    height: Union[int, float]
    width: Union[int, float]
