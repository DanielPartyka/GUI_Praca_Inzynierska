import json
from typing import List

import jsonschema as js

from uamf import BlockMeta, schemas
from uamf.ds import Size


class UArrayMeta:
    def __init__(self, name: str, size: Size, rows_number: int,
                 columns_number: int, blocks_number: int):
        """Microarray metadata

        Args:
            name (str): name of microarray
            size (Size): microarray image size
            rows_number (int): number of microarray rows
            columns_number (int): number of microarray columns
            blocks_number (int): number of microarray blocks

        **The parameters of the UArrayMeta object are also its
        attributes**

        Attributes:
            blocks (List[BlockMeta]): list of blocks
        """

        self.name = name
        self.size: Size = size
        self.rows_number: int = rows_number
        self.columns_number: int = columns_number
        self.blocks_number: int = blocks_number

        self.blocks: List[BlockMeta] = []

        self._members = ('name', 'height', 'width', 'rows_number',
                         'columns_number', 'blocks_number', 'blocks')

    # region: Generic properties
    @property
    def height(self):
        """int: microarray image height"""
        return self.size.height

    @height.setter
    def height(self, height):
        self.size.height = height

    @property
    def width(self):
        """int: microarray image width"""
        return self.size.width

    @width.setter
    def width(self, width):
        self.size.width = width

    # endregion

    @property
    def as_dict(self):
        """dict: dict representation of the microarray metadata"""
        uarray_dict = {m: getattr(self, m) for m in self._members if
                       m != 'blocks'}

        serialized_blocks = []
        for block in self.blocks:
            serialized_blocks.append(block.as_dict)

        uarray_dict['blocks'] = serialized_blocks
        return uarray_dict

    @property
    def as_json(self):
        """json: json representation of the microarray metadata"""
        uarray_json = json.dumps(self.as_dict)
        return uarray_json

    def add_block(self, block: BlockMeta):
        """Add a single block metadata to UArray metadata

        Args:
            block (BlockMeta): block metadata

        Raises:
            TypeError: if `block` is not instance of BlockMeta
        """
        if not isinstance(block, BlockMeta):
            raise TypeError

        self.blocks.append(block)

    def save(self, filepath: str, override: bool = False):
        """Save the uArray metadata object to file

        Args:
            filepath (str): path to the saved file
            override (bool): override if file exist

        Raises:
            FileExistsError: if file exist and override set on False
        """
        mode = 'w' if override else 'x'

        with open(filepath, mode) as output_file:
            json.dump(self.as_dict, output_file)

    @staticmethod
    def from_file(filepath: str) -> "UArrayMeta":
        """Create UArrayMeta object from file (.uamf)

        Args:
            filepath (str): path to the file to be loaded

        Returns:
            UArrayMeta: UArrayMeta object based on loaded json file

        Raises:
            KeyError: if not found required key in loaded json
        """
        with open(filepath, 'r') as input_file:
            uarray_json = json.load(input_file)

        UArrayMeta.validate(uarray_json)

        name = uarray_json['name']
        size = Size(uarray_json['height'], uarray_json['width'])
        rows_number = uarray_json['rows_number']
        columns_number = uarray_json['columns_number']
        blocks_number = uarray_json['blocks_number']

        uarray_object = UArrayMeta(name, size, rows_number, columns_number,
                                   blocks_number)

        for block in uarray_json["blocks"]:
            block_meta = BlockMeta.from_dict(block)

            uarray_object.add_block(block_meta)

        return uarray_object

    @staticmethod
    def validate(uarray_dict: dict):
        """Validate UArrayMeta dict

        Args:
            uarray_dict (dict): dict with serialized UArrayMeta object

        Raises:
            `jsonschema.exceptions.ValidationError`: if the dictionary
                contains an invalid object
        """

        js.validate(uarray_dict, schemas.uarray_schema)

        for block in uarray_dict['blocks']:
            BlockMeta.validate(block)
