from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    readme = f.read()

with open('.version', 'r', encoding='utf-8') as f:
    version = f.read()

setup(
    name='uamf',
    version=version,
    description='',
    long_description=readme,
    long_description_content_type='text/markdown',
    author='Adam Konieczny',
    packages=find_packages(include=['uamf', 'uamf.*']),
    package_data={'': ['LICENSE']},
    include_package_data=True,
    python_requires='>=3.8, <4',
    zip_safe=False,
    install_requires=[
        'jsonschema==3.2.0'
    ],
)
