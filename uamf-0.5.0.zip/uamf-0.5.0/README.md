# uArray Meta File

## Use package in other projects

### Download project

**Using HTTPS** `git clone https://github.com/akonieczny/uamf.git`

or **using SSH** `git clone git@github.com:akonieczny/uamf.git`

### Go to project directory

```
cd uamf
```

### Install package

```
python setup.py install
```

### Import and use package

Check documentation for more information.

```python
from uamf import BlockMeta
from uamf.ds import Size, Spot, Point

block_metadata = BlockMeta('test.png', Size(1000, 1200), 25, 30, 750)

spot = Spot(1, 1, 1, Point(23, 26), Size(10, 16), Point(41, 45))
block_metadata.add_spot(spot)
```

## Developer setup

Developer setup is described for Linux system with ***sh*** compatible shells.

### Download project

**Using HTTPS** `git clone https://github.com/akonieczny/uamf.git`

or **using SSH** `git clone git@github.com:akonieczny/uamf.git`

### Go to project directory
```
cd uamf
```

### Create virtual environment
```
python3 -m venv .venv
```

### Activate virtual environment
```
source .venv/bin/activate
```

### Install requirements
```
pip install -r requirements.txt
```

### Start programming :)

### Deactivate virtual environment
```
dectivate
```


## Generate documentation

### Install sphinx
```
sudo apt install python3-sphinx
```

### Go to documentation directory
```
cd docs
```

### Make documentation
```
make html
```

### Documentation will be available in `./docs/_build/html` directory
