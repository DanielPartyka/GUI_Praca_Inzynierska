import json

from dataclasses import dataclass
from typing import Union

from . import Size
from . import Point

@dataclass
class Spot:
    # noinspection PyUnresolvedReferences
    """Spot metadata

    Args:
        index (int): spot number
        row (int): spot location, row number
        column (int): spot location, column number
        position (Point): spot top-left corner
        size (Size): spot size
        center (Point): spot center
        manually_verified (bool): is spot manually verified

    Example:
        >>> spot_data = Spot(1, 10, 11, Point(100, 120), Size(12, 14),
        ...                  Point(105, 126),  False)
        >>>
        >>> spot_index = spot_data.index  # get the spot number
        >>> spot_data.index = 12 # set the spot number to 12

    **The parameters of the Spot object are also its attributes**
    """

    index: int
    row: int
    column: int

    position: Point
    size: Size
    center: Point

    manually_verified: bool = False

    _members = ('index', 'row', 'column', 'pos_x', 'pos_y', 'height', 'width',
                'center_x', 'center_y', 'manually_verified')

    # region: Generic properties
    @property
    def pos_x(self):
        """int: spot top-left corner, x coordinate"""
        return self.position.x

    @pos_x.setter
    def pos_x(self, x):
        self.position.x = x

    @property
    def pos_y(self):
        """int: spot top-left corner, y coordinate"""
        return self.position.y

    @pos_y.setter
    def pos_y(self, y):
        self.position.y = y

    @property
    def height(self):
        """int: spot height"""
        return self.size.height

    @height.setter
    def height(self, height):
        self.size.height = height

    @property
    def width(self):
        """int: spot width"""
        return self.size.width

    @width.setter
    def width(self, width):
        self.size.width = width

    @property
    def center_x(self):
        """int: spot center, x coordinate"""
        return self.center.x

    @center_x.setter
    def center_x(self, x):
        self.center.x = x

    @property
    def center_y(self):
        """int: spot center, y coordinate"""
        return self.center.y

    @center_y.setter
    def center_y(self, y):
        self.center.y = y

    # endregion

    @property
    def as_dict(self) -> dict:
        """dict: dict representation of the spot metadata"""
        spot_as_dict = {m: getattr(self, m) for m in self._members}
        return spot_as_dict

    @property
    def as_json(self) -> str:
        """str: json representation of the spot metadata"""
        return json.dumps(self.as_dict)

    @property
    def as_list(self) -> list:
        """list: list representation of the spot metadata"""
        spot_as_list = [getattr(self, m) for m in self._members]
        return spot_as_list

    @staticmethod
    def from_dict(spot_as_dict: dict) -> "Spot":
        """Create spot from dict

        Args:
            spot_as_dict (dict): dict representation of a spot metadata

        Returns:
            Spot: spot object
        """
        index = spot_as_dict["index"]
        row = spot_as_dict["row"]
        column = spot_as_dict["column"]
        position = Point(spot_as_dict["pos_x"], spot_as_dict["pos_y"])
        size = Size(spot_as_dict["height"], spot_as_dict["width"])
        center = Point(spot_as_dict["center_x"], spot_as_dict["center_y"])
        manually_verified = spot_as_dict["manually_verified"]

        spot = Spot(index, row, column,
                    position, size, center,
                    manually_verified)
        return spot

    @staticmethod
    def from_list(spot_as_list: Union[list, tuple]) -> "Spot":
        """Create spot from list

        Args:
            spot_as_list (Union[list, tuple]): list representation
            of a spot metadata

        Returns:
            Spot: spot object
        """
        spot_args = list(spot_as_list.copy())

        spot_args[3] = Point(*spot_as_list[3:5])
        spot_args[5] = Size(*spot_as_list[5:7])
        spot_args[7] = Point(*spot_as_list[7:9])

        del spot_args[8], spot_args[6], spot_args[4]

        spot = Spot(*spot_args)
        return spot
