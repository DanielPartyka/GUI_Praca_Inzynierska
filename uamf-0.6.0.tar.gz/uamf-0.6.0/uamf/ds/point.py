from dataclasses import dataclass


@dataclass
class Point:
    # noinspection PyUnresolvedReferences
    """Point data structure

    Args:
        x (int): x coordinate
        y (int): y coordinate

    Example:
        >>> point = Point(12, 15)
        >>>
        >>> x_coordinate = point.x  # get the x coordinate
        >>> point.y = 12 # set the y coordinate to 12

    **The parameters of the Point object are also its attributes**
    """

    x: int
    y: int
