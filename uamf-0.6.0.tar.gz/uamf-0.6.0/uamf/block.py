import json
import logging
from typing import List, Optional

import jsonschema as js

from uamf import schemas
from uamf.ds import Point, Size, Spot

logger = logging.getLogger('uamf')


class BlockMeta:
    def __init__(self, filename: str, size: Size,
                 rows_number: int, columns_number: int, spots_number: int,
                 origin_name: str = "", position: Point = None,
                 spot_type: type = dict):
        """Microarray block metadata

        Args:
            filename (str): file name with extension
            size (Size): block image size
            rows_number (int): number of block rows
            columns_number (int): number of block columns
            spots_number (int): number of block spots
            origin_name (str): name of origin microarray
            position (Point): block top-left corner position in the
                origin microarray
            spot_type (type): type of exported spots, must be "dict" or
                "list"

        **The parameters of the BlockMeta object are also its
        attributes**

        Attributes:
            spots (List[Spots]): list of spots
            griding_method (str): block griding method
            griding_manually_verified (bool): girding has been manually
                verified
        """

        self.filename: str = filename
        self.origin_name: str = origin_name
        self.size: Size = size
        self.position: Point = position or Point(0, 0)

        self.rows_number: int = rows_number
        self.columns_number: int = columns_number
        self.spots_number: int = spots_number

        self.spots: List[Spot] = []

        self.mean_spot_size: Optional[Size] = None
        self.griding_method: Optional[str] = ""
        self.griding_manually_verified: bool = False

        if spot_type not in (list, dict):
            self.spot_type = dict
            logger.error(f'The "spot_type" parameter must be {dict} or {list},'
                         f' not {spot_type}. Set the default value {dict})')
        else:
            self.spot_type = spot_type

        self._members = ('filename', 'origin_name', 'height', 'width', 'pos_x',
                         'pos_y', 'rows_number', 'columns_number',
                         'spots_number', 'spots', 'mean_spot_height',
                         'mean_spot_width', 'griding_method',
                         'griding_manually_verified')

    # region: Generic properties
    @property
    def pos_x(self):
        """int: spot top-left corner, x coordinate"""
        return self.position.x

    @pos_x.setter
    def pos_x(self, x):
        self.position.x = x

    @property
    def pos_y(self):
        """int: spot top-left corner, y coordinate"""
        return self.position.y

    @pos_y.setter
    def pos_y(self, y):
        self.position.y = y

    @property
    def height(self):
        """int: block height"""
        return self.size.height

    @height.setter
    def height(self, height):
        self.size.height = height

    @property
    def width(self):
        """int: block width"""
        return self.size.width

    @width.setter
    def width(self, width):
        self.size.width = width

    @property
    def mean_spot_height(self):
        """int: average spot height"""
        return self.mean_spot_size.height

    @mean_spot_height.setter
    def mean_spot_height(self, height):
        self.mean_spot_size.height = height

    @property
    def mean_spot_width(self):
        """int: average spot width"""
        return self.mean_spot_size.width

    @mean_spot_width.setter
    def mean_spot_width(self, width):
        self.mean_spot_size.width = width

    # endregion

    @property
    def as_dict(self):
        """dict: dict representation of the Block metadata"""
        block_dict = {m: getattr(self, m) for m in self._members if
                      m != 'spots'}

        serialized_spots = []
        for spot in self.spots:
            new_spot = spot.as_dict if self.spot_type == dict else spot.as_list
            serialized_spots.append(new_spot)

        block_dict['spots'] = serialized_spots
        return block_dict

    @property
    def as_json(self):
        """json: json representation of the Block metadata"""
        block_json = json.dumps(self.as_dict)
        return block_json

    def add_spot(self, spot: Spot):
        """Add a spot data to Block metadata

        Args:
            spot (Spot): spot metadata

        Raises:
            TypeError: if `spot` is not instance of Spot
        """
        if not isinstance(spot, Spot):
            raise TypeError

        self.spots.append(spot)

    def calc_mean_spot_size(self):
        """Calculate mean spot size

        Warning: Also calculates the number of spots
        """

        self.calc_spots_number()

        mean_spot_height = \
            sum([spot.size.height for spot in self.spots]) / self.spots_number
        mean_spot_width = \
            sum([spot.size.width for spot in self.spots]) / self.spots_number

        self.mean_spot_size = Size(mean_spot_height, mean_spot_width)

    def calc_spots_number(self):
        """Calculate the number of spots"""
        self.spots_number = len(self.spots)

    def save(self, filepath: str, override: bool = False):
        """Save the Block metadata object to file

        Args:
            filepath (str): path to the saved file
            override (bool): override if file exist

        Raises:
            FileExistsError: if file exist and override set on False
        """
        mode = 'w' if override else 'x'

        with open(filepath, mode) as output_file:
            json.dump(self.as_dict, output_file)

    @staticmethod
    def from_dict(block_dict: dict) -> "BlockMeta":
        """Create BlockMeta object from dict

        Args:
            block_dict (dict): dict wit block metadata

        Returns:
            BlockMeta: BlockMeta object based on loaded json file

        Raises:
            KeyError: if not found required key in loaded json
        """

        BlockMeta.validate(block_dict)

        filename = block_dict['filename']
        size = Size(block_dict['height'], block_dict['width'])
        rows_number = block_dict['rows_number']
        columns_number = block_dict['columns_number']
        spots_number = block_dict['spots_number']
        origin_name = block_dict['origin_name']
        position = Point(block_dict['pos_x'], block_dict['pos_y'])
        mean_spot_size = Size(block_dict['mean_spot_height'],
                              block_dict['mean_spot_width'])

        _spots = block_dict['spots']
        if not _spots:
            spot_type = dict
        else:
            spot_type = type(_spots[0])

        griding_method = block_dict["griding_method"]
        griding_manually_verified = block_dict["griding_manually_verified"]

        block_object = BlockMeta(filename, size, rows_number, columns_number,
                                 spots_number, origin_name, position, spot_type)
        block_object.mean_spot_size = mean_spot_size
        block_object.griding_method = griding_method
        block_object.griding_manually_verified = griding_manually_verified

        for spot in block_dict["spots"]:
            if spot_type == dict:
                spot_object = Spot.from_dict(spot)
            else:
                spot_object = Spot.from_list(spot)
            block_object.add_spot(spot_object)

        return block_object

    @staticmethod
    def from_file(filepath: str) -> "BlockMeta":
        """Create BlockMeta object from file (.bmf)

        Args:
            filepath (str): path to the file to be loaded

        Returns:
            BlockMeta: BlockMeta object based on loaded json file

        Raises:
            KeyError: if not found required key in loaded json
        """
        with open(filepath, 'r') as input_file:
            block_dict = json.load(input_file)

        block_object = BlockMeta.from_dict(block_dict)

        return block_object

    @staticmethod
    def validate(block_dict: dict, schema: dict = None):
        """Validate BlockMeta dict

        Args:
            block_dict (dict): dict with serialized BlockMeta object
            schema (dict): dict with Json Schema for serialized
                BlockMeta object, NOT SUPPORTED FOR NOW

        Raises:
            `jsonschema.exceptions.ValidationError`: if the dictionary
                contains an invalid object
            `jsonschema.exceptions.SchemaError` if the schema is invalid
        """

        js.validate(block_dict, schemas.block_schema)
        # TODO: Add validation of passed schema here
