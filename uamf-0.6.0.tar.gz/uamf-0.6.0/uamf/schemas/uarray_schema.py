uarray_schema = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "UArray Metadata",
    "type": "object",
    "properties": {
        "name": {
            "type": "string"
        },
        "height": {
            "type": "integer"
        },
        "width": {
            "type": "integer"
        },
        "rows_number": {
            "type": "integer"
        },
        "columns_number": {
            "type": "integer"
        },
        "blocks_number": {
            "type": "integer"
        },
        "spots": {
            "type": "array",
            "oneOf": [
                {
                    "maxItems": 0
                },
                {
                    "minItems": 1,
                    "items": {
                        "type": "object"
                    }
                }
            ]
        }
    }
}
